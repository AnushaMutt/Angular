import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule} from '@angular/forms';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MovieComponent } from '../movie/movie.component';
import { HomeComponent } from '../home/home.component';
import { PowerPipe } from '../shared/transform-spaces.pipes';
import { MovieRating } from '../shared/rating.component';
import { MovieDetailComponent } from '../moviedetail/moviedetail.component';
import { UserComponent } from "src/users/user.component";
import { MovieService } from "src/movie/movie.service";
import { HttpClientModule } from "@angular/common/http";



@NgModule({
  declarations: [
    AppComponent,
    MovieComponent,
    PowerPipe,
    HomeComponent,
    MovieDetailComponent,
    UserComponent,
    MovieRating,
    MovieService
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
