import { Component,OnChanges,OnInit,OnDestroy } from '@angular/core';
import {ActivatedRoute,Router} from '@angular/router';
import {Imovie} from './../movie/movie';

@Component({
  selector: 'moviedetail',
  templateUrl: './moviedetail.component.html'
 
})
export class MovieDetailComponent   {

pgtitle:string="Movie Details";
movie:Imovie;

constructor (private route:ActivatedRoute, private router:Router ){};

    ngOnInit(): void {
        
let id=this.route.snapshot.paramMap.get('id');
this.pgtitle+= `:${id}`;
this.movie={

    'mId':+id, 
    'moviesName': 'kgf',
    'actor':'yash',
    'movieRating':5,

};

 }
 
}