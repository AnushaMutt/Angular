

import { Injectable } from "@angular/core";
import { Imovie } from "src/movie/movie";

@Injectable({
    providedIn:'root'
})

export class MovieService{
getMovies():Imovie[]{

    return[
        

{'mId':1, 'moviesName': 'kgf','actor':'yash','movieRating': 5 },
{'mId':2 ,'moviesName': 'bahubali','actor':'prabas','movieRating': 4 },
{'mId':3 ,'moviesName': 'inception','actor':'Leo','movieRating': 3 }
      
        
    ];
}

}