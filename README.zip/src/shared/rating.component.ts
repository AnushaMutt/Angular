import { Input, Component, Output, EventEmitter } from '@angular/core';



@Component({
  selector: 'mov-rating',
  templateUrl: './rating.component.html'
 
})



export class MovieRating{
@Input() rating:number;
starWidth:number;
@Output() ratingClick:EventEmitter<string> = new EventEmitter<string>();

ngOnChanges():void{
    this.starWidth=+this.rating*75/5;
}

 onclick():void{
     this.ratingClick.emit('the movie rating ${this.rating} is clicked');
 }
}