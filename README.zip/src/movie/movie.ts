export interface Imovie{
    mId:number;
    moviesName:string;
     actor:string;
     movieRating:number;

}